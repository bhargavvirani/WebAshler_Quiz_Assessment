export interface IEmployee {
    Emp_Id : number;
    Emp_Tag_Number : string;
    First_Name : string;
    Last_Name : string;
    Email : string;
    Department : string;
    BirthDate : string;
    Designation : string;
    Age: number;
    NumberOfQuestions: number;
    Time: number;
    IsEmailSend: boolean;
    Result: string;
    Id: number;
}

export interface IInputEmployee {
    Emp_Id : number;
    Emp_Tag_Number : string;
    First_Name : string;
    Last_Name : string;
    Email : string;
    Department : string;
    BirthDate : string;
    Designation : string;
    NumberOfQuestions : number;
    Time: number;
    IsEmailSend: boolean;
    Result: string;
    Id: number;
}