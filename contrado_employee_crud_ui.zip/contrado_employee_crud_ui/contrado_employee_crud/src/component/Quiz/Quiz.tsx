import React, { useState, useEffect, useCallback } from "react";
import { useParams } from "react-router-dom";
import "../Quiz/Quiz.style.css";
import {
  Button,
  Container,
  Paper,
  Typography,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio,
} from "@mui/material";
import {
  fetchQuestionsList,
  fetchEmployeeDetails,
  editEmployee,
} from "../Employee.service";
import { IEmployee, IInputEmployee } from "../Employee.type";

interface IQuestions {
  question: any;
  options: any[];
  answer: any;
}

const Quiz = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [selectedOption, setSelectedOption] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [questions, setQuestions] = useState<IQuestions[]>();
  const [isStartQuiz, setIsStartQuiz] = useState(false);
  const [minute, setMinute] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [isExamTimeOver, setIsExamTimeOver] = useState(false);
  const [examStatus, setExamStatus] = useState("");
  const [isClickOnFinish, setIsClickOnFinish] = useState(false);
  const [employeeDetails, setEmployeeDetails] = useState<IEmployee>({
    Emp_Id: 0,
    Emp_Tag_Number: "",
    First_Name: "",
    Last_Name: "",
    Email: "",
    Department: "",
    BirthDate: "",
    Designation: "",
    Age: 0,
    NumberOfQuestions: 0,
    Time: 0,
    IsEmailSend: false,
    Result: "",
    Id: 0,
  });

  let { emp_Id } = useParams();

  useEffect(() => {
    let interval: any;

    if (isActive) {
      interval = setInterval(() => {
        setSeconds((prevSeconds) => prevSeconds + 1);
      }, 1000);
    } else {
      clearInterval(interval);
    }

    return () => clearInterval(interval);
  }, [isActive]);

  const handleStop = () => {
    setIsActive((prevIsActive) => !prevIsActive);
  };

  useEffect(() => {
    if (minute - Math.floor(seconds / 60) === 0) {
      handleStop();
      setShowScore(true);
      setIsExamTimeOver(true);
      setIsClickOnFinish(true);
      updateExamStatus("You scored " + score + " out of " + questions?.length);
    }
    else {
        setIsClickOnFinish(false);
    }
  }, [seconds]);

  const handleReset = () => {
    setSeconds(0);
    setIsActive(false);
  };

  const OnPageLoad = useCallback(() => {
    getEmployee();
    getQuestionsList();
  }, []);

  useEffect(() => {
    setIsClickOnFinish(false);
    OnPageLoad();
  }, [OnPageLoad]);

  const updateExamStatus = async (msg:string) => {
    let inputEmployeeData: IInputEmployee = {
      Emp_Id: emp_Id === undefined ? 0 : parseInt(emp_Id),
      Emp_Tag_Number: employeeDetails.Emp_Tag_Number,
      First_Name: employeeDetails.First_Name,
      Last_Name: employeeDetails.Last_Name,
      Email: employeeDetails.Email,
      Department: employeeDetails.Department,
      Designation: employeeDetails.Designation,
      NumberOfQuestions: employeeDetails.NumberOfQuestions,
      Time: employeeDetails.Time,
      IsEmailSend: employeeDetails.IsEmailSend,
      Result: msg,
      Id: employeeDetails.Id,
      BirthDate: employeeDetails.BirthDate,
    };
    setExamStatus(msg);
    await editEmployee(emp_Id, inputEmployeeData);
  };

  async function getQuestionsList() {
    var questionsList = await fetchQuestionsList(emp_Id);
    const questions = questionsList?.map((item: any) => ({
      question: item.question,
      options: [item.option1, item.option2, item.option3, item.option4],
      answer: item.answer,
    }));
    setQuestions(questions);
  }

  async function getEmployee() {
    var employeeDetails = await fetchEmployeeDetails(emp_Id);
    setEmployeeDetails({
      Emp_Id: employeeDetails?.emp_Id,
      Emp_Tag_Number: employeeDetails?.emp_Tag_Number,
      First_Name: employeeDetails?.first_Name,
      Last_Name: employeeDetails?.last_Name,
      Email: employeeDetails?.email,
      Department: employeeDetails?.department,
      BirthDate: employeeDetails?.birthDate,
      Designation: employeeDetails?.designation,
      Age: employeeDetails?.age,
      NumberOfQuestions: employeeDetails?.numberOfQuestions,
      Time: employeeDetails?.time,
      IsEmailSend: employeeDetails?.isEmailSend,
      Result: employeeDetails?.result,
      Id: employeeDetails?.id,
    });
    if (employeeDetails?.time) {
      setMinute(() => {
        return Math.floor(employeeDetails.time / 60);
      });
    }
    if (employeeDetails?.result) {
        debugger;
        setExamStatus(() => {
          return employeeDetails.result;
        });
      }
  }

  const handleOptionChange = (event: any) => {
    setSelectedOption(event.target.value);
  };

  const handleSubmitAnswer = () => {
    if (selectedOption === questions?.[currentQuestion]?.answer) {
      setScore(score + 1);
    }
    setSubmitted(true);
  };

  const handleNextQuestion = () => {
    const nextQuestion = currentQuestion + 1;
    if (questions && nextQuestion < questions!.length) {
      setCurrentQuestion(nextQuestion);
      setSelectedOption("");
      setSubmitted(false);
    } else {
      handleStop();
      setShowScore(true);
      setIsExamTimeOver(true);
      setIsClickOnFinish(true);
      updateExamStatus("You scored " + score + " out of " + questions?.length);
    }
  };

  const restartQuiz = () => {
    setSeconds(0);
    setIsActive(false);
    setCurrentQuestion(0);
    setScore(0);
    setShowScore(false);
    setSelectedOption("");
    setSubmitted(false);
  };

  const startQuiz = () => {
    setIsStartQuiz(true);
    setCurrentQuestion(0);
    setScore(0);
    setShowScore(false);
    setSelectedOption("");
    setSubmitted(false);
    setIsActive((prevIsActive) => !prevIsActive);
    updateExamStatus("Exam Start");
  };

  return (
    <>
    { (!examStatus.includes(" out of ") || isClickOnFinish) && <div>
      <article className="article-header">
        <header>
          <div style={{ display: "inline-block" }}>
            <h1 className="margin-left-10">QUIZ</h1>
          </div>
          {
            <Container
              maxWidth="sm"
              style={{
                display: "inline-block",
                textAlign: "right",
                marginRight: "50px",
              }}
            >
              <Typography variant="h5" gutterBottom>
                {minute - Math.floor(seconds / 60)} Minutes Pending
              </Typography>
            </Container>
          }
        </header>
      </article>
      <section className="section-content">
        {!isStartQuiz && (
          <div>
            <h2>
              You have {minute} minutes to take the quiz. Once the time finish
              your answers will be submitted automatically. Click the button to
              start quiz.
            </h2>
            <Button variant="contained" color="primary" onClick={startQuiz}>
              Start Quiz
            </Button>
          </div>
        )}
        {questions && isStartQuiz && (
          <Container maxWidth="sm">
            <Paper elevation={3} style={{ padding: "20px", marginTop: "20px" }}>
              {showScore ? (
                <div>
                  <Typography variant="h5" gutterBottom>
                    You scored {score} out of {questions!.length}
                  </Typography>
                </div>
              ) : (
                <div>
                  <div>
                    <Typography variant="h6" gutterBottom>
                      Question {currentQuestion + 1}/{questions!.length}
                    </Typography>
                    <Typography variant="body1" gutterBottom>
                      {questions?.[currentQuestion]?.question}
                    </Typography>
                    <FormControl component="fieldset">
                      <RadioGroup
                        value={selectedOption}
                        onChange={handleOptionChange}
                      >
                        {questions?.[currentQuestion].options.map(
                          (option, index) => (
                            <FormControlLabel
                              key={index}
                              value={option}
                              control={<Radio />}
                              label={option}
                              disabled={submitted}
                            />
                          )
                        )}
                      </RadioGroup>
                    </FormControl>
                  </div>
                  {!submitted && (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={handleSubmitAnswer}
                      disabled={!selectedOption}
                    >
                      Submit
                    </Button>
                  )}
                  {submitted && (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={handleNextQuestion}
                    >
                      {currentQuestion === questions!.length - 1
                        ? "Finish"
                        : "Next"}
                    </Button>
                  )}
                </div>
              )}
            </Paper>
          </Container>
        )}
      </section>
      </div>}
      { (examStatus.includes(" out of ") && !isClickOnFinish) && <h1>Already Submited</h1>}
    </>
  );
};

export default Quiz;
