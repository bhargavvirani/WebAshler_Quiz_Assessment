import "./Home.style.css";
import EmployeeList from "./EmployeeList";

const Home = () => {
  return (
    <>
      <article className="article-header">
        <header>
          <h1>Quiz Management System</h1>
        </header>
      </article>

      <section className="section-content">
        <EmployeeList></EmployeeList>
      </section>
    </>
  );
};

export default Home;
