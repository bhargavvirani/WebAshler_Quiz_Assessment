const fetchWithAuth  = (enpoint: string, method: string,body:any | undefined = undefined) => {
    var header = new Headers();
    return fetchWithAuthAndHeader(enpoint,method,header,body);
}

const fetchWithAuthAndHeader = (endpoint: string,method:string,header:Headers,body:any | undefined = undefined)=>{
    var url = 'https://localhost:7034/api' + endpoint;
    if(!header.has('Content-Type')){
        header.set('Content-Type','application/json');
    }
    return fetch(url,{method:method,headers:header,body:body});
}

const getEmployeeList = async () => {
    const response = await fetchWithAuth('/Employee','GET');
    const data = await response.json();
    return data;
}

const fetchQuestionsList = async (emp_Id:any) => {
    const response = await fetchWithAuth('/Questions/GetAllQuestionsByEmployee/' + emp_Id,'GET');
    const data = await response.json();
    return data;
}

const fetchEmployeeDetails = async (emp_Id:any) => {
    const response = await fetchWithAuth('/Employee/' + emp_Id,'GET');
    const data = await response.json();
    return data;
}

const addEmployee = async (body:any) => {
    const response = await fetchWithAuth('/Employee','POST',JSON.stringify(body));
    const data = await response.json();
    return data;
}

const sendMail = async (body:any) => {
    fetchWithAuth('/Email','POST',JSON.stringify(body));
}

const editEmployee = async (emp_Id:any,body:any) => {
    fetchWithAuth('/Employee/' + emp_Id,'PUT',JSON.stringify(body));
}

const deleteEmployee = async (emp_Id:any) => {
    fetchWithAuth('/Employee/' + emp_Id,'DELETE');
}

export {getEmployeeList, addEmployee, editEmployee, deleteEmployee, fetchQuestionsList, fetchEmployeeDetails, sendMail}