import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import logo from './logo.svg';
import './App.css';
import Home from './component/Home';
import Quiz from './component/Quiz/Quiz';

function App() {
  return (
    <Router>
      <div>
        <Routes>
          <Route path="/" Component={Home} />
          <Route path="/Quiz/:emp_Id" Component={Quiz} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
