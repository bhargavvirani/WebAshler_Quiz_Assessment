﻿using contrado_employee_crud.Models;
using contrado_employee_crud.Models.DTO;
using contrado_employee_crud.Repositories;

namespace contrado_employee_crud.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepository _employeeRepository;
        public EmployeeService(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        public async Task<int> AddEmployee(EmployeeDTO employee)
        {
            return await _employeeRepository.AddEmployee(new Employee()
            {
                Emp_Id = 0,
                Last_Name = employee.Last_Name,
                First_Name = employee.First_Name,
                BirthDate = employee.BirthDate,
                Department = employee.Department,
                Designation = employee.Designation,
                Email = employee.Email,
                Emp_Tag_Number = employee.Emp_Tag_Number,
                Id = employee.Id,
                IsEmailSend = employee.IsEmailSend,
                NumberOfQuestions = employee.NumberOfQuestions,
                Result = employee.Result,
                Time = employee.Time,
            });
        }

        public Task<bool> DeleteEmployee(int emp_Id)
        {
            return _employeeRepository.DeleteEmployee(emp_Id);
        }

        public async Task<IEnumerable<Employee>> GetAllEmployees()
        {
            return await _employeeRepository.GetAllEmployees();
        }

        public async Task<Employee> GetEmployeeById(int emp_Id)
        {
            return await _employeeRepository.GetEmployeeById(emp_Id);
        }

        public Task<bool> UpdateEmployee(int emp_Id, EmployeeDTO employee)
        {
            return _employeeRepository.UpdateEmployee(emp_Id, new EmployeeDTO()
            {
                Last_Name = employee.Last_Name,
                First_Name = employee.First_Name,
                BirthDate = employee.BirthDate,
                Department = employee.Department,
                Designation = employee.Designation,
                Email = employee.Email,
                Emp_Tag_Number = employee.Emp_Tag_Number,
                Id = employee.Id,
                IsEmailSend = employee.IsEmailSend,
                NumberOfQuestions = employee.NumberOfQuestions,
                Result = employee.Result,
                Time = employee.Time,
            });
        }
    }
}
