﻿using contrado_employee_crud.Models;
using contrado_employee_crud.Models.DTO;

namespace contrado_employee_crud.Services
{
    public interface IQuestionsService
    {
        Task<IEnumerable<Questions>> GetAllQuestions();
        Task<IEnumerable<QuestionCategories>> GetAllQuestionCategories();
        Task<IEnumerable<Questions>> GetAllQuestionByEmployee(int emp_Id);
    }
}
