﻿using contrado_employee_crud.Models;
using contrado_employee_crud.Models.DTO;
using contrado_employee_crud.Repositories;

namespace contrado_employee_crud.Services
{
    public class QuestionsService : IQuestionsService
    {
        private readonly IQuestionsRepository _questionsRepository;
        public QuestionsService(IQuestionsRepository questionsRepository)
        {
            _questionsRepository = questionsRepository;
        }

        public async Task<IEnumerable<Questions>> GetAllQuestionByEmployee(int emp_Id)
        {
            return await _questionsRepository.GetAllQuestionByEmployee(emp_Id);
        }

        public async Task<IEnumerable<QuestionCategories>> GetAllQuestionCategories()
        {
            return await _questionsRepository.GetAllQuestionCategories();
        }

        public async Task<IEnumerable<Questions>> GetAllQuestions()
        {
            return await _questionsRepository.GetAllQuestions();
        }
    }
}
