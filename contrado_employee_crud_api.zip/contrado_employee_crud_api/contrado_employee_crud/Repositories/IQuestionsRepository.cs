﻿using contrado_employee_crud.Models;

namespace contrado_employee_crud.Repositories
{
    public interface IQuestionsRepository
    {
        Task<IEnumerable<Questions>> GetAllQuestions();
        Task<IEnumerable<QuestionCategories>> GetAllQuestionCategories();
        Task<IEnumerable<Questions>> GetAllQuestionByEmployee(int emp_Id);
    }
}
