﻿using contrado_employee_crud.Models;
using Microsoft.EntityFrameworkCore;

namespace contrado_employee_crud.Repositories
{
    public class QuestionsRepository : IQuestionsRepository
    {
        private readonly EmpoyeeCrudDbContext _dbContext;

        public QuestionsRepository(EmpoyeeCrudDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<Questions>> GetAllQuestionByEmployee(int emp_Id)
        {
            int numberOfQuestions = _dbContext.Employees
                                    .Where(e => e.Emp_Id == emp_Id)
                                    .Select(e => e.NumberOfQuestions)
                                    .FirstOrDefault();

            var query = (from questions in _dbContext.Questions
                         join employee in _dbContext.Employees
                         on questions.Id equals employee.Id
                         where employee.Emp_Id == emp_Id
                         select new Questions
                         {
                             QuestionId = questions.QuestionId,
                             Question = questions.Question,
                             Option1 = questions.Option1,
                             Option2 = questions.Option2,
                             Option3 = questions.Option3,
                             Option4 = questions.Option4,
                             Answer = questions.Answer,
                             Id = questions.Id,
                         }).Take(numberOfQuestions);

            return await query.ToListAsync();
        }

        public async Task<IEnumerable<QuestionCategories>> GetAllQuestionCategories()
        {
            return await _dbContext.QuestionCategories.ToListAsync();
        }

        public async Task<IEnumerable<Questions>> GetAllQuestions()
        {
            var query = from questions in _dbContext.Questions
                        join questionCategory in _dbContext.QuestionCategories
                        on questions.Id equals questionCategory.Id
                        select new Questions
                        {
                            QuestionId = questions.QuestionId,
                            Question = questions.Question,
                            Option1 = questions.Option1,
                            Option2 = questions.Option2,
                            Option3 = questions.Option3,
                            Option4 = questions.Option4,
                            Answer = questions.Answer,
                            Id = questions.Id,
                            QuestionCategory = questionCategory
                        };
            return await query.ToListAsync();
        }
    }
}
