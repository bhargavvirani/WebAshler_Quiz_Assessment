﻿using contrado_employee_crud.Models;
using Microsoft.EntityFrameworkCore;

namespace contrado_employee_crud.Repositories
{
    public class EmpoyeeCrudDbContext : DbContext
    {
        public EmpoyeeCrudDbContext(DbContextOptions<EmpoyeeCrudDbContext> options) : base(options)
        {
        }

        public DbSet<Employee> Employees { get; set; }

        public DbSet<QuestionCategories> QuestionCategories { get; set; }
        public DbSet<Questions> Questions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Questions>().HasData(
            new Questions { QuestionId = 1, Question = "What is .NET?", Option1 = "A programming language", Option2 = "A software framework", Option3 = "A database management system", Option4 = "An operating system", Answer = "A software framework", Id = 1 },
new Questions { QuestionId = 2, Question = "Which programming languages can be used within the .NET framework?", Option1 = "Only C#", Option2 = "Only VB.NET", Option3 = "Any language that is supported by the Common Language Runtime (CLR)", Option4 = "None, .NET has its own proprietary language", Answer = "Any language that is supported by the Common Language Runtime (CLR)", Id = 1 },
new Questions { QuestionId = 3, Question = "What is the primary function of the Common Language Runtime (CLR) in .NET?", Option1 = "To compile code into machine language", Option2 = "To provide a common set of class libraries", Option3 = "To manage and execute .NET programs", Option4 = "To manage relational databases", Answer = "To manage and execute .NET programs", Id = 1 },
new Questions { QuestionId = 4, Question = "Which of the following is not a component of the .NET framework?", Option1 = "ASP.NET", Option2 = "ADO.NET", Option3 = "VBScript", Option4 = "WinForms", Answer = "VBScript", Id = 1 },
new Questions { QuestionId = 5, Question = "What is ASP.NET used for?", Option1 = "Building desktop applications", Option2 = "Developing web applications", Option3 = "Managing databases", Option4 = "Creating mobile apps", Answer = "Developing web applications", Id = 1 },
new Questions { QuestionId = 6, Question = "Which file extension is used for .NET assembly files?", Option1 = ".exe", Option2 = ".dll", Option3 = ".bat", Option4 = ".com", Answer = ".dll", Id = 1 },
new Questions { QuestionId = 7, Question = "What does ADO.NET stand for?", Option1 = "Active Database Objects .NET", Option2 = "Advanced Data Objects .NET", Option3 = "ActiveX Data Objects .NET", Option4 = "Application Data Objects .NET", Answer = "ActiveX Data Objects .NET", Id = 1 },
new Questions { QuestionId = 8, Question = "Which of the following is NOT a valid data provider in ADO.NET?", Option1 = "SQL Server Provider", Option2 = "OLE DB Provider", Option3 = "Oracle Provider", Option4 = "HTTP Provider", Answer = "HTTP Provider", Id = 1 },
new Questions { QuestionId = 9, Question = "What is the purpose of the Global Assembly Cache (GAC)?", Option1 = "To store global variables for all .NET applications", Option2 = "To cache frequently accessed assemblies for better performance", Option3 = "To store shared assemblies that are globally available to .NET applications", Option4 = "To store compiled machine code for faster execution", Answer = "To store shared assemblies that are globally available to .NET applications", Id = 1 },
new Questions { QuestionId = 10, Question = "Which of the following is a benefit of using managed code in .NET?", Option1 = "Higher performance", Option2 = "More control over memory management", Option3 = "Platform independence", Option4 = "Better integration with native code", Answer = "Platform independence", Id = 1 },
new Questions { QuestionId = 11, Question = "What is the default language for .NET development?", Option1 = "C#", Option2 = "VB.NET", Option3 = "C++", Option4 = "Java", Answer = "C#", Id = 1 },
new Questions { QuestionId = 12, Question = "Which of the following statements about .NET Core is true?", Option1 = "It is only available for Windows operating systems", Option2 = "It is a cross-platform, open-source version of the .NET framework", Option3 = "It does not support web development", Option4 = "It is primarily used for legacy applications", Answer = "It is a cross-platform, open-source version of the .NET framework", Id = 1 },
new Questions { QuestionId = 13, Question = "What is the purpose of the 'using' keyword in C#?", Option1 = "To import namespaces", Option2 = "To create instances of classes", Option3 = "To define variables", Option4 = "To handle exceptions", Answer = "To import namespaces", Id = 1 },
new Questions { QuestionId = 14, Question = "Which of the following is NOT a type of .NET application?", Option1 = "Console Application", Option2 = "Windows Forms Application", Option3 = "Web Application", Option4 = "Database Application", Answer = "Database Application", Id = 1 },
new Questions { QuestionId = 15, Question = "What is the primary function of the JIT compiler in .NET?", Option1 = "To interpret bytecode", Option2 = "To convert source code into bytecode", Option3 = "To optimize and compile Intermediate Language (IL) code into native machine code", Option4 = "To execute SQL queries", Answer = "To optimize and compile Intermediate Language (IL) code into native machine code", Id = 1 },
new Questions { QuestionId = 16, Question = "What is LINQ in .NET?", Option1 = "A programming language", Option2 = "A tool for database administration", Option3 = "A language-integrated query for .NET", Option4 = "A type of .NET assembly", Answer = "A language-integrated query for .NET", Id = 1 },
new Questions { QuestionId = 17, Question = "Which of the following is true about .NET assemblies?", Option1 = "They contain only source code.", Option2 = "They are the primary unit of deployment in .NET.", Option3 = "They are limited to a single programming language.", Option4 = "They can only be executed on Windows platforms.", Answer = "They are the primary unit of deployment in .NET.", Id = 1 },
new Questions { QuestionId = 18, Question = "What is the purpose of the ConfigurationManager class in .NET?", Option1 = "To manage configuration settings for .NET applications", Option2 = "To manage database connections", Option3 = "To manage user authentication", Option4 = "To manage memory allocation", Answer = "To manage configuration settings for .NET applications", Id = 1 },
new Questions { QuestionId = 19, Question = "Which of the following is true about garbage collection in .NET?", Option1 = "Developers have full control over when garbage collection occurs.", Option2 = "Garbage collection ensures that objects are automatically deallocated when they are no longer in use.", Option3 = "Garbage collection is performed by the operating system.", Option4 = "Garbage collection is not supported in .NET.", Answer = "Garbage collection ensures that objects are automatically deallocated when they are no longer in use.", Id = 1 },
new Questions { QuestionId = 20, Question = "What is the role of the Web.config file in ASP.NET?", Option1 = "To store application settings and configurations", Option2 = "To define the structure of web pages", Option3 = "To manage user authentication", Option4 = "To handle HTTP requests and responses", Answer = "To store application settings and configurations", Id = 1 },

new Questions
{
    QuestionId = 21,
    Question = "Which of the following best describes Java?",
    Option1 = "A programming language developed by Microsoft",
    Option2 = "A programming language used for building Android apps",
    Option3 = "A programming language primarily used for web development",
    Option4 = "A programming language known for its platform independence",
    Answer = "A programming language known for its platform independence",
    Id = 2
},

new Questions
{
    QuestionId = 22,
    Question = "What is the difference between an abstract class and an interface in Java?",
    Option1 = "An abstract class can have constructors, while an interface cannot.",
    Option2 = "An interface can have method implementations, while an abstract class cannot.",
    Option3 = "A class can implement multiple interfaces, but can extend only one abstract class.",
    Option4 = "An abstract class can have both abstract and non-abstract methods, while an interface can only have abstract methods.",
    Answer = "A class can implement multiple interfaces, but can extend only one abstract class.",
    Id = 2
},

new Questions
{
    QuestionId = 23,
    Question = "What is a JVM in the context of Java?",
    Option1 = "Java Variable Manager",
    Option2 = "Java Visual Machine",
    Option3 = "Java Virtual Method",
    Option4 = "Java Virtual Machine",
    Answer = "Java Virtual Machine",
    Id = 2
},

new Questions
{
    QuestionId = 24,
    Question = "Which keyword is used to prevent a method from being overridden in Java?",
    Option1 = "override",
    Option2 = "final",
    Option3 = "static",
    Option4 = "private",
    Answer = "final",
    Id = 2
},

new Questions
{
    QuestionId = 25,
    Question = "What is the purpose of the 'this' keyword in Java?",
    Option1 = "To reference the superclass",
    Option2 = "To reference the current instance of the class",
    Option3 = "To reference the immediate subclass",
    Option4 = "To reference the static members of the class",
    Answer = "To reference the current instance of the class",
    Id = 2
},

new Questions
{
    QuestionId = 26,
    Question = "What is the main advantage of using exception handling in Java?",
    Option1 = "It improves the performance of the code",
    Option2 = "It allows the program to ignore errors",
    Option3 = "It provides a mechanism to gracefully handle runtime errors",
    Option4 = "It reduces the size of the compiled code",
    Answer = "It provides a mechanism to gracefully handle runtime errors",
    Id = 2
},

new Questions
{
    QuestionId = 27,
    Question = "Which data structure in Java allows storing elements in a sorted order?",
    Option1 = "ArrayList",
    Option2 = "LinkedList",
    Option3 = "HashSet",
    Option4 = "TreeSet",
    Answer = "TreeSet",
    Id = 2
},

new Questions
{
    QuestionId = 28,
    Question = "What is the output of the following code snippet? \n\npublic class Test {\n    public static void main(String[] args) {\n        System.out.println(10 > 5 ? \"Yes\" : \"No\");\n    }\n}",
    Option1 = "Yes",
    Option2 = "No",
    Option3 = "10",
    Option4 = "Compilation Error",
    Answer = "Yes",
    Id = 2
},

new Questions
{
    QuestionId = 29,
    Question = "Which of the following statements about packages in Java is true?",
    Option1 = "Packages help in organizing classes into folders",
    Option2 = "A class can belong to multiple packages",
    Option3 = "Packages cannot contain sub-packages",
    Option4 = "Packages are used to avoid naming conflicts and to control access",
    Answer = "Packages are used to avoid naming conflicts and to control access",
    Id = 2
},

new Questions
{
    QuestionId = 30,
    Question = "What is the correct way to declare a constant variable in Java?",
    Option1 = "final int CONSTANT = 10;",
    Option2 = "const int CONSTANT = 10;",
    Option3 = "static final int CONSTANT = 10;",
    Option4 = "final CONSTANT = 10;",
    Answer = "static final int CONSTANT = 10;",
    Id = 2
},

new Questions
{
    QuestionId = 31,
    Question = "What is the role of a constructor in Java?",
    Option1 = "To initialize the instance variables of the class",
    Option2 = "To define the structure of the class",
    Option3 = "To provide access to the superclass methods",
    Option4 = "To define the behavior of the class",
    Answer = "To initialize the instance variables of the class",
    Id = 2
},

new Questions
{
    QuestionId = 32,
    Question = "What is the difference between '==' and '.equals()' in Java?",
    Option1 = "'==' is used to compare object references, while '.equals()' is used to compare object contents.",
    Option2 = "'==' is used to compare primitive data types, while '.equals()' is used to compare objects.",
    Option3 = "'==' is used to compare string objects, while '.equals()' is used to compare integer values.",
    Option4 = "'==' is used to compare array elements, while '.equals()' is used to compare array sizes.",
    Answer = "'==' is used to compare object references, while '.equals()' is used to compare object contents.",
    Id = 2
},

new Questions
{
    QuestionId = 33,
    Question = "Which of the following statements about inheritance in Java is true?",
    Option1 = "Java supports multiple inheritance",
    Option2 = "A class can inherit from multiple classes in Java",
    Option3 = "In Java, all classes inherit directly from the Object class",
    Option4 = "Inheritance is not supported in Java",
    Answer = "In Java, all classes inherit directly from the Object class",
    Id = 2
},

new Questions
{
    QuestionId = 34,
    Question = "What is the purpose of the 'super' keyword in Java?",
    Option1 = "To reference the current instance of the class",
    Option2 = "To invoke the superclass constructor or method",
    Option3 = "To prevent a method from being overridden",
    Option4 = "To reference the immediate subclass",
    Answer = "To invoke the superclass constructor or method",
    Id = 2
},

new Questions
{
    QuestionId = 35,
    Question = "Which of the following statements about access modifiers in Java is true?",
    Option1 = "Private members are accessible only within the same package",
    Option2 = "Protected members are accessible outside the class hierarchy",
    Option3 = "Public members are accessible only within the same class",
    Option4 = "Default (package-private) members are accessible from any class",
    Answer = "Private members are accessible only within the same class",
    Id = 2
},

new Questions
{
    QuestionId = 36,
    Question = "What is the primary purpose of the toString() method in Java?",
    Option1 = "To convert an object to a String representation",
    Option2 = "To concatenate two strings",
    Option3 = "To compare two strings",
    Option4 = "To convert a String to an object",
    Answer = "To convert an object to a String representation",
    Id = 2
},

new Questions
{
    QuestionId = 37,
    Question = "Which of the following statements about Java constructors is true?",
    Option1 = "Constructors can be inherited by subclasses.",
    Option2 = "Constructors can have a return type.",
    Option3 = "If a class does not define a constructor, Java provides a default constructor.",
    Option4 = "Constructors cannot be overloaded.",
    Answer = "If a class does not define a constructor, Java provides a default constructor.",
    Id = 2
},

new Questions
{
    QuestionId = 38,
    Question = "What is the purpose of the instanceof operator in Java?",
    Option1 = "To determine if two objects are equal.",
    Option2 = "To compare the memory addresses of two objects.",
    Option3 = "To check if an object is an instance of a particular class or interface.",
    Option4 = "To access the properties of an object.",
    Answer = "To check if an object is an instance of a particular class or interface.",
    Id = 2
},

new Questions
{
    QuestionId = 39,
    Question = "What is the difference between a Stack and a Queue in Java?",
    Option1 = "A Stack follows the LIFO (Last In, First Out) principle, while a Queue follows the FIFO (First In, First Out) principle.",
    Option2 = "A Stack follows the FIFO principle, while a Queue follows the LIFO principle.",
    Option3 = "Both Stack and Queue follow the LIFO principle.",
    Option4 = "Both Stack and Queue follow the FIFO principle.",
    Answer = "A Stack follows the LIFO (Last In, First Out) principle, while a Queue follows the FIFO (First In, First Out) principle.",
    Id = 2
},

new Questions
{
    QuestionId = 40,
    Question = "Which component is used to compile, debug and execute the java programs?",
    Option1 = "JRE",
    Option2 = "JIT",
    Option3 = "JDK",
    Option4 = "JVM",
    Answer = "JDK",
    Id = 2
},

new Questions
{
    QuestionId = 41,
    Question = "Which AWS service is a fully managed container orchestration service?",
    Option1 = "Amazon ECS",
    Option2 = "Amazon EKS",
    Option3 = "AWS Lambda",
    Option4 = "AWS Fargate",
    Answer = "Amazon EKS",
    Id = 3
},
new Questions
{
    QuestionId = 42,
    Question = "Which AWS service is suitable for real-time messaging and event-driven architectures?",
    Option1 = "Amazon SQS",
    Option2 = "Amazon SNS",
    Option3 = "Amazon MQ",
    Option4 = "Amazon Kinesis",
    Answer = "Amazon Kinesis",
    Id = 3
},
new Questions
{
    QuestionId = 43,
    Question = "What is the primary use case for Amazon S3?",
    Option1 = "Virtual Private Cloud (VPC)",
    Option2 = "Object storage",
    Option3 = "Block storage",
    Option4 = "Content delivery network (CDN)",
    Answer = "Object storage",
    Id = 3
},
new Questions
{
    QuestionId = 44,
    Question = "Which AWS service allows you to analyze large datasets using SQL queries?",
    Option1 = "Amazon Redshift",
    Option2 = "Amazon Athena",
    Option3 = "Amazon RDS",
    Option4 = "Amazon DynamoDB",
    Answer = "Amazon Athena",
    Id = 3
},
new Questions
{
    QuestionId = 45,
    Question = "What type of database does Amazon DynamoDB belong to?",
    Option1 = "Relational database",
    Option2 = "Document database",
    Option3 = "Key-value store",
    Option4 = "Graph database",
    Answer = "Key-value store",
    Id = 3
},
new Questions
{
    QuestionId = 46,
    Question = "Which AWS service is a fully managed stream processing service?",
    Option1 = "Amazon S3",
    Option2 = "Amazon Kinesis",
    Option3 = "AWS Glue",
    Option4 = "Amazon Athena",
    Answer = "Amazon Kinesis",
    Id = 3
},
new Questions
{
    QuestionId = 47,
    Question = "What AWS service provides a scalable, high-performance graph database?",
    Option1 = "Amazon Aurora",
    Option2 = "Amazon Neptune",
    Option3 = "Amazon DynamoDB",
    Option4 = "Amazon Redshift",
    Answer = "Amazon Neptune",
    Id = 3
},
new Questions
{
    QuestionId = 48,
    Question = "Which AWS service enables you to deploy serverless applications?",
    Option1 = "AWS Lambda",
    Option2 = "Amazon EC2",
    Option3 = "Amazon ECS",
    Option4 = "Amazon EKS",
    Answer = "AWS Lambda",
    Id = 3
},
new Questions
{
    QuestionId = 49,
    Question = "What AWS service provides a scalable data warehouse solution?",
    Option1 = "Amazon RDS",
    Option2 = "Amazon Redshift",
    Option3 = "Amazon DynamoDB",
    Option4 = "Amazon Neptune",
    Answer = "Amazon Redshift",
    Id = 3
},
new Questions
{
    QuestionId = 50,
    Question = "Which AWS service provides a fully managed Apache Hadoop framework?",
    Option1 = "Amazon EMR",
    Option2 = "Amazon EFS",
    Option3 = "AWS Glue",
    Option4 = "Amazon Redshift",
    Answer = "Amazon EMR",
    Id = 3
},
new Questions
{
    QuestionId = 51,
    Question = "Which AWS service provides a managed Kubernetes service?",
    Option1 = "Amazon EKS",
    Option2 = "Amazon ECS",
    Option3 = "AWS Lambda",
    Option4 = "Amazon EC2",
    Answer = "Amazon EKS",
    Id = 3
},
new Questions
{
    QuestionId = 52,
    Question = "Which AWS service is a fully managed NoSQL database?",
    Option1 = "Amazon RDS",
    Option2 = "Amazon DynamoDB",
    Option3 = "Amazon Redshift",
    Option4 = "Amazon Neptune",
    Answer = "Amazon DynamoDB",
    Id = 3
},
new Questions
{
    QuestionId = 53,
    Question = "What AWS service allows you to run containers without managing servers or clusters?",
    Option1 = "AWS Lambda",
    Option2 = "Amazon ECS",
    Option3 = "Amazon EKS",
    Option4 = "AWS Fargate",
    Answer = "AWS Fargate",
    Id = 3
},
new Questions
{
    QuestionId = 54,
    Question = "Which AWS service is a fully managed file storage service for use with EC2 instances?",
    Option1 = "Amazon EBS",
    Option2 = "Amazon EFS",
    Option3 = "Amazon S3",
    Option4 = "AWS Storage Gateway",
    Answer = "Amazon EFS",
    Id = 3
},
new Questions
{
    QuestionId = 55,
    Question = "What AWS service allows you to automate the deployment, management, and scaling of applications?",
    Option1 = "Amazon ECS",
    Option2 = "AWS Lambda",
    Option3 = "AWS Elastic Beanstalk",
    Option4 = "AWS OpsWorks",
    Answer = "AWS Elastic Beanstalk",
    Id = 3
},
new Questions
{
    QuestionId = 56,
    Question = "Which AWS service is a fully managed service for relational databases?",
    Option1 = "Amazon RDS",
    Option2 = "Amazon DynamoDB",
    Option3 = "Amazon Redshift",
    Option4 = "Amazon Aurora",
    Answer = "Amazon RDS",
    Id = 3
},
new Questions
{
    QuestionId = 57,
    Question = "What AWS service provides a fast, fully managed petabyte-scale data warehouse solution?",
    Option1 = "Amazon RDS",
    Option2 = "Amazon DynamoDB",
    Option3 = "Amazon Redshift",
    Option4 = "Amazon Aurora",
    Answer = "Amazon Redshift",
    Id = 3
},
new Questions
{
    QuestionId = 58,
    Question = "Which AWS service provides a fully managed, serverless data integration service?",
    Option1 = "Amazon Glue",
    Option2 = "AWS Data Pipeline",
    Option3 = "Amazon Kinesis",
    Option4 = "AWS Direct Connect",
    Answer = "Amazon Glue",
    Id = 3
},
new Questions
{
    QuestionId = 59,
    Question = "What AWS service provides a managed blockchain service?",
    Option1 = "Amazon Managed Blockchain",
    Option2 = "Amazon Quantum Ledger Database (QLDB)",
    Option3 = "Amazon Neptune",
    Option4 = "Amazon Redshift",
    Answer = "Amazon Managed Blockchain",
    Id = 3
},
new Questions
{
    QuestionId = 60,
    Question = "Which AWS service allows you to create and manage APIs for your backend services?",
    Option1 = "Amazon API Gateway",
    Option2 = "AWS Lambda",
    Option3 = "AWS AppSync",
    Option4 = "Amazon Neptune",
    Answer = "Amazon API Gateway",
    Id = 3
}
            );
        }

    }
}
