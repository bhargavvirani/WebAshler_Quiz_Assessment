﻿using System.ComponentModel.DataAnnotations;

namespace contrado_employee_crud.Models.DTO
{
    public class EmailDTO
    {
        [Required]
        public string ToAddress { get; set; }

        [Required]
        public string Subject { get; set; }

        [Required]
        public string Message { get; set; }
    }
}
