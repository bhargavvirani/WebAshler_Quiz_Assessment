﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace contrado_employee_crud.Models
{
    public class Employee
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Emp_Id { get; set; }

        [Required]
        [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Only alphanumeric characters are allowed.")]
        public string Emp_Tag_Number { get; set; }

        [Required]
        public string First_Name { get; set; }

        [Required]
        public string Last_Name { get; set;}

        [Required]
        [EmailAddress(ErrorMessage = "Invalid email address.")]
        public string Email { get; set; }

        [Required]
        public string Department { get; set; }

        [Required]
        public DateTime BirthDate { get; set; }

        [Required]
        public string Designation { get; set; }

        [Required]
        public int NumberOfQuestions { get; set; } = 20;

        [Required]
        public int Time { get; set; } = 1200;

        public int Id { get; set; }

        [JsonIgnore]
        [ForeignKey("Id")]
        public virtual QuestionCategories QuestionCategory { get; set; }

        public bool IsEmailSend { get; set; }

        public string Result { get; set; }
    }
}
