﻿namespace contrado_employee_crud.Models
{
    public class QuestionCategories
    {
        public int Id { get; set; }
        public string Category { get; set; }
        public virtual ICollection<Questions> Questions { get; set; }
        public virtual ICollection<Employee> Employees { get; set; }
    }
}
