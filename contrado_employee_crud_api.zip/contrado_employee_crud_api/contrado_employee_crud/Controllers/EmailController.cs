﻿using contrado_employee_crud.Models.DTO;
using contrado_employee_crud.Util;
using Microsoft.AspNetCore.Mvc;

namespace contrado_employee_crud.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        [HttpPost]
        public async Task<IActionResult> SendEmail(EmailDTO emailDTO)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            await EmailUtility.SendMail(emailDTO.Message, emailDTO.Subject, emailDTO.ToAddress);

            return Ok();
        }
    }
}
