﻿using contrado_employee_crud.Models;
using contrado_employee_crud.Models.DTO;
using contrado_employee_crud.Services;
using Microsoft.AspNetCore.Mvc;

namespace contrado_employee_crud.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService _employeeService;

        public EmployeeController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        [HttpGet]
        public async Task<IEnumerable<Employee>> GetEmployees()
        {
            return await _employeeService.GetAllEmployees();
        }

        [Route("{emp_Id}")]
        [HttpGet]
        public async Task<IActionResult> GetEmployee(int emp_Id)
        {
            if (emp_Id < 1)
                return BadRequest();
            var employee = await _employeeService.GetEmployeeById(emp_Id);
            if (employee == null)
                return NotFound();
            return Ok(employee);
        }

        [HttpPost]
        public async Task<IActionResult> CreateEmployee(EmployeeDTO employee)
        {
            if(!ModelState.IsValid)
                return BadRequest();

            var id = await _employeeService.AddEmployee(employee);
            return Ok(id);
        }

        [HttpPut("{emp_Id}")]
        public async Task<IActionResult> UpdateEmployee(int emp_Id, EmployeeDTO employee)
        {
            if (employee == null || emp_Id == 0)
                return BadRequest();

            var isUpdated = await _employeeService.UpdateEmployee(emp_Id, employee);

            if (!isUpdated)
                return NotFound();

            return Ok();
        }

        [HttpDelete("{emp_Id}")]
        public async Task<IActionResult> DeleteEmployee(int emp_Id)
        {
            if (emp_Id < 1)
                return BadRequest();

            var isDeleted = await _employeeService.DeleteEmployee(emp_Id);

            if (!isDeleted)
                return NotFound();

            return Ok();
        }
    }
}
