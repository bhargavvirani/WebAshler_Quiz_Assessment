﻿using contrado_employee_crud.Models;
using contrado_employee_crud.Services;
using Microsoft.AspNetCore.Mvc;

namespace contrado_employee_crud.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuestionsController : ControllerBase
    {
        private readonly IQuestionsService _questionsService;

        public QuestionsController(IQuestionsService questionsService)
        {
            _questionsService = questionsService;
        }

        [Route("GetAllQuestions")]
        [HttpGet]
        public async Task<IEnumerable<Questions>> GetQuestions()
        {
            return await _questionsService.GetAllQuestions();
        }

        [Route("GetAllQuestionsByEmployee/{emp_Id}")]
        [HttpGet]
        public async Task<IEnumerable<Questions>> GetAllQuestionsByEmployee(int emp_Id)
        {
            return await _questionsService.GetAllQuestionByEmployee(emp_Id);
        }

        [Route("GetQuestionCategories")]
        [HttpGet]
        public async Task<IEnumerable<QuestionCategories>> GetQuestionCategories()
        {
            return await _questionsService.GetAllQuestionCategories();
        }
    }
}
