﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace contrado_employee_crud.Migrations
{
    /// <inheritdoc />
    public partial class updateemployeetable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "NumberOfQuestions",
                table: "Employees",
                type: "int",
                nullable: false,
                defaultValue: 20);

            migrationBuilder.AddColumn<int>(
                name: "Time",
                table: "Employees",
                type: "int",
                nullable: false,
                defaultValue: 1200);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NumberOfQuestions",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "Time",
                table: "Employees");
        }
    }
}
