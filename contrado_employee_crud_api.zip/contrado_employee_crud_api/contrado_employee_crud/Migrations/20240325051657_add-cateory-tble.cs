﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace contrado_employee_crud.Migrations
{
    /// <inheritdoc />
    public partial class addcateorytble : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "QuestionCategories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Category = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QuestionCategories", x => x.Id);
                });

            migrationBuilder.InsertData(
        table: "QuestionCategories",
        columns: new[] { "Category" },
        values: new object[,]
        {
            { ".NET" },
            { "JAVA" },
            { "AWS" }
        });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "QuestionCategories");
        }
    }
}
