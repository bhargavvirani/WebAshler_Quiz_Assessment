﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace contrado_employee_crud.Migrations
{
    /// <inheritdoc />
    public partial class _123 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Questions",
                columns: table => new
                {
                    QuestionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Question = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Option1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Option2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Option3 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Option4 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Answer = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Questions", x => x.QuestionId);
                    table.ForeignKey(
                        name: "FK_Questions_QuestionCategories_Id",
                        column: x => x.Id,
                        principalTable: "QuestionCategories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Questions",
                columns: new[] { "QuestionId", "Answer", "Id", "Option1", "Option2", "Option3", "Option4", "Question" },
                values: new object[,]
                {
                    { 1, "A software framework", 1, "A programming language", "A software framework", "A database management system", "An operating system", "What is .NET?" },
                    { 2, "Any language that is supported by the Common Language Runtime (CLR)", 1, "Only C#", "Only VB.NET", "Any language that is supported by the Common Language Runtime (CLR)", "None, .NET has its own proprietary language", "Which programming languages can be used within the .NET framework?" },
                    { 3, "To manage and execute .NET programs", 1, "To compile code into machine language", "To provide a common set of class libraries", "To manage and execute .NET programs", "To manage relational databases", "What is the primary function of the Common Language Runtime (CLR) in .NET?" },
                    { 4, "VBScript", 1, "ASP.NET", "ADO.NET", "VBScript", "WinForms", "Which of the following is not a component of the .NET framework?" },
                    { 5, "Developing web applications", 1, "Building desktop applications", "Developing web applications", "Managing databases", "Creating mobile apps", "What is ASP.NET used for?" },
                    { 6, ".dll", 1, ".exe", ".dll", ".bat", ".com", "Which file extension is used for .NET assembly files?" },
                    { 7, "ActiveX Data Objects .NET", 1, "Active Database Objects .NET", "Advanced Data Objects .NET", "ActiveX Data Objects .NET", "Application Data Objects .NET", "What does ADO.NET stand for?" },
                    { 8, "HTTP Provider", 1, "SQL Server Provider", "OLE DB Provider", "Oracle Provider", "HTTP Provider", "Which of the following is NOT a valid data provider in ADO.NET?" },
                    { 9, "To store shared assemblies that are globally available to .NET applications", 1, "To store global variables for all .NET applications", "To cache frequently accessed assemblies for better performance", "To store shared assemblies that are globally available to .NET applications", "To store compiled machine code for faster execution", "What is the purpose of the Global Assembly Cache (GAC)?" },
                    { 10, "Platform independence", 1, "Higher performance", "More control over memory management", "Platform independence", "Better integration with native code", "Which of the following is a benefit of using managed code in .NET?" },
                    { 11, "C#", 1, "C#", "VB.NET", "C++", "Java", "What is the default language for .NET development?" },
                    { 12, "It is a cross-platform, open-source version of the .NET framework", 1, "It is only available for Windows operating systems", "It is a cross-platform, open-source version of the .NET framework", "It does not support web development", "It is primarily used for legacy applications", "Which of the following statements about .NET Core is true?" },
                    { 13, "To import namespaces", 1, "To import namespaces", "To create instances of classes", "To define variables", "To handle exceptions", "What is the purpose of the 'using' keyword in C#?" },
                    { 14, "Database Application", 1, "Console Application", "Windows Forms Application", "Web Application", "Database Application", "Which of the following is NOT a type of .NET application?" },
                    { 15, "To optimize and compile Intermediate Language (IL) code into native machine code", 1, "To interpret bytecode", "To convert source code into bytecode", "To optimize and compile Intermediate Language (IL) code into native machine code", "To execute SQL queries", "What is the primary function of the JIT compiler in .NET?" },
                    { 16, "A language-integrated query for .NET", 1, "A programming language", "A tool for database administration", "A language-integrated query for .NET", "A type of .NET assembly", "What is LINQ in .NET?" },
                    { 17, "They are the primary unit of deployment in .NET.", 1, "They contain only source code.", "They are the primary unit of deployment in .NET.", "They are limited to a single programming language.", "They can only be executed on Windows platforms.", "Which of the following is true about .NET assemblies?" },
                    { 18, "To manage configuration settings for .NET applications", 1, "To manage configuration settings for .NET applications", "To manage database connections", "To manage user authentication", "To manage memory allocation", "What is the purpose of the ConfigurationManager class in .NET?" },
                    { 19, "Garbage collection ensures that objects are automatically deallocated when they are no longer in use.", 1, "Developers have full control over when garbage collection occurs.", "Garbage collection ensures that objects are automatically deallocated when they are no longer in use.", "Garbage collection is performed by the operating system.", "Garbage collection is not supported in .NET.", "Which of the following is true about garbage collection in .NET?" },
                    { 20, "To store application settings and configurations", 1, "To store application settings and configurations", "To define the structure of web pages", "To manage user authentication", "To handle HTTP requests and responses", "What is the role of the Web.config file in ASP.NET?" },
                    { 21, "A programming language known for its platform independence", 2, "A programming language developed by Microsoft", "A programming language used for building Android apps", "A programming language primarily used for web development", "A programming language known for its platform independence", "Which of the following best describes Java?" },
                    { 22, "A class can implement multiple interfaces, but can extend only one abstract class.", 2, "An abstract class can have constructors, while an interface cannot.", "An interface can have method implementations, while an abstract class cannot.", "A class can implement multiple interfaces, but can extend only one abstract class.", "An abstract class can have both abstract and non-abstract methods, while an interface can only have abstract methods.", "What is the difference between an abstract class and an interface in Java?" },
                    { 23, "Java Virtual Machine", 2, "Java Variable Manager", "Java Visual Machine", "Java Virtual Method", "Java Virtual Machine", "What is a JVM in the context of Java?" },
                    { 24, "final", 2, "override", "final", "static", "private", "Which keyword is used to prevent a method from being overridden in Java?" },
                    { 25, "To reference the current instance of the class", 2, "To reference the superclass", "To reference the current instance of the class", "To reference the immediate subclass", "To reference the static members of the class", "What is the purpose of the 'this' keyword in Java?" },
                    { 26, "It provides a mechanism to gracefully handle runtime errors", 2, "It improves the performance of the code", "It allows the program to ignore errors", "It provides a mechanism to gracefully handle runtime errors", "It reduces the size of the compiled code", "What is the main advantage of using exception handling in Java?" },
                    { 27, "TreeSet", 2, "ArrayList", "LinkedList", "HashSet", "TreeSet", "Which data structure in Java allows storing elements in a sorted order?" },
                    { 28, "Yes", 2, "Yes", "No", "10", "Compilation Error", "What is the output of the following code snippet? \n\npublic class Test {\n    public static void main(String[] args) {\n        System.out.println(10 > 5 ? \"Yes\" : \"No\");\n    }\n}" },
                    { 29, "Packages are used to avoid naming conflicts and to control access", 2, "Packages help in organizing classes into folders", "A class can belong to multiple packages", "Packages cannot contain sub-packages", "Packages are used to avoid naming conflicts and to control access", "Which of the following statements about packages in Java is true?" },
                    { 30, "static final int CONSTANT = 10;", 2, "final int CONSTANT = 10;", "const int CONSTANT = 10;", "static final int CONSTANT = 10;", "final CONSTANT = 10;", "What is the correct way to declare a constant variable in Java?" },
                    { 31, "To initialize the instance variables of the class", 2, "To initialize the instance variables of the class", "To define the structure of the class", "To provide access to the superclass methods", "To define the behavior of the class", "What is the role of a constructor in Java?" },
                    { 32, "'==' is used to compare object references, while '.equals()' is used to compare object contents.", 2, "'==' is used to compare object references, while '.equals()' is used to compare object contents.", "'==' is used to compare primitive data types, while '.equals()' is used to compare objects.", "'==' is used to compare string objects, while '.equals()' is used to compare integer values.", "'==' is used to compare array elements, while '.equals()' is used to compare array sizes.", "What is the difference between '==' and '.equals()' in Java?" },
                    { 33, "In Java, all classes inherit directly from the Object class", 2, "Java supports multiple inheritance", "A class can inherit from multiple classes in Java", "In Java, all classes inherit directly from the Object class", "Inheritance is not supported in Java", "Which of the following statements about inheritance in Java is true?" },
                    { 34, "To invoke the superclass constructor or method", 2, "To reference the current instance of the class", "To invoke the superclass constructor or method", "To prevent a method from being overridden", "To reference the immediate subclass", "What is the purpose of the 'super' keyword in Java?" },
                    { 35, "Private members are accessible only within the same class", 2, "Private members are accessible only within the same package", "Protected members are accessible outside the class hierarchy", "Public members are accessible only within the same class", "Default (package-private) members are accessible from any class", "Which of the following statements about access modifiers in Java is true?" },
                    { 36, "To convert an object to a String representation", 2, "To convert an object to a String representation", "To concatenate two strings", "To compare two strings", "To convert a String to an object", "What is the primary purpose of the toString() method in Java?" },
                    { 37, "If a class does not define a constructor, Java provides a default constructor.", 2, "Constructors can be inherited by subclasses.", "Constructors can have a return type.", "If a class does not define a constructor, Java provides a default constructor.", "Constructors cannot be overloaded.", "Which of the following statements about Java constructors is true?" },
                    { 38, "To check if an object is an instance of a particular class or interface.", 2, "To determine if two objects are equal.", "To compare the memory addresses of two objects.", "To check if an object is an instance of a particular class or interface.", "To access the properties of an object.", "What is the purpose of the instanceof operator in Java?" },
                    { 39, "A Stack follows the LIFO (Last In, First Out) principle, while a Queue follows the FIFO (First In, First Out) principle.", 2, "A Stack follows the LIFO (Last In, First Out) principle, while a Queue follows the FIFO (First In, First Out) principle.", "A Stack follows the FIFO principle, while a Queue follows the LIFO principle.", "Both Stack and Queue follow the LIFO principle.", "Both Stack and Queue follow the FIFO principle.", "What is the difference between a Stack and a Queue in Java?" },
                    { 40, "JDK", 2, "JRE", "JIT", "JDK", "JVM", "Which component is used to compile, debug and execute the java programs?" },
                    { 41, "Amazon EKS", 3, "Amazon ECS", "Amazon EKS", "AWS Lambda", "AWS Fargate", "Which AWS service is a fully managed container orchestration service?" },
                    { 42, "Amazon Kinesis", 3, "Amazon SQS", "Amazon SNS", "Amazon MQ", "Amazon Kinesis", "Which AWS service is suitable for real-time messaging and event-driven architectures?" },
                    { 43, "Object storage", 3, "Virtual Private Cloud (VPC)", "Object storage", "Block storage", "Content delivery network (CDN)", "What is the primary use case for Amazon S3?" },
                    { 44, "Amazon Athena", 3, "Amazon Redshift", "Amazon Athena", "Amazon RDS", "Amazon DynamoDB", "Which AWS service allows you to analyze large datasets using SQL queries?" },
                    { 45, "Key-value store", 3, "Relational database", "Document database", "Key-value store", "Graph database", "What type of database does Amazon DynamoDB belong to?" },
                    { 46, "Amazon Kinesis", 3, "Amazon S3", "Amazon Kinesis", "AWS Glue", "Amazon Athena", "Which AWS service is a fully managed stream processing service?" },
                    { 47, "Amazon Neptune", 3, "Amazon Aurora", "Amazon Neptune", "Amazon DynamoDB", "Amazon Redshift", "What AWS service provides a scalable, high-performance graph database?" },
                    { 48, "AWS Lambda", 3, "AWS Lambda", "Amazon EC2", "Amazon ECS", "Amazon EKS", "Which AWS service enables you to deploy serverless applications?" },
                    { 49, "Amazon Redshift", 3, "Amazon RDS", "Amazon Redshift", "Amazon DynamoDB", "Amazon Neptune", "What AWS service provides a scalable data warehouse solution?" },
                    { 50, "Amazon EMR", 3, "Amazon EMR", "Amazon EFS", "AWS Glue", "Amazon Redshift", "Which AWS service provides a fully managed Apache Hadoop framework?" },
                    { 51, "Amazon EKS", 3, "Amazon EKS", "Amazon ECS", "AWS Lambda", "Amazon EC2", "Which AWS service provides a managed Kubernetes service?" },
                    { 52, "Amazon DynamoDB", 3, "Amazon RDS", "Amazon DynamoDB", "Amazon Redshift", "Amazon Neptune", "Which AWS service is a fully managed NoSQL database?" },
                    { 53, "AWS Fargate", 3, "AWS Lambda", "Amazon ECS", "Amazon EKS", "AWS Fargate", "What AWS service allows you to run containers without managing servers or clusters?" },
                    { 54, "Amazon EFS", 3, "Amazon EBS", "Amazon EFS", "Amazon S3", "AWS Storage Gateway", "Which AWS service is a fully managed file storage service for use with EC2 instances?" },
                    { 55, "AWS Elastic Beanstalk", 3, "Amazon ECS", "AWS Lambda", "AWS Elastic Beanstalk", "AWS OpsWorks", "What AWS service allows you to automate the deployment, management, and scaling of applications?" },
                    { 56, "Amazon RDS", 3, "Amazon RDS", "Amazon DynamoDB", "Amazon Redshift", "Amazon Aurora", "Which AWS service is a fully managed service for relational databases?" },
                    { 57, "Amazon Redshift", 3, "Amazon RDS", "Amazon DynamoDB", "Amazon Redshift", "Amazon Aurora", "What AWS service provides a fast, fully managed petabyte-scale data warehouse solution?" },
                    { 58, "Amazon Glue", 3, "Amazon Glue", "AWS Data Pipeline", "Amazon Kinesis", "AWS Direct Connect", "Which AWS service provides a fully managed, serverless data integration service?" },
                    { 59, "Amazon Managed Blockchain", 3, "Amazon Managed Blockchain", "Amazon Quantum Ledger Database (QLDB)", "Amazon Neptune", "Amazon Redshift", "What AWS service provides a managed blockchain service?" },
                    { 60, "Amazon API Gateway", 3, "Amazon API Gateway", "AWS Lambda", "AWS AppSync", "Amazon Neptune", "Which AWS service allows you to create and manage APIs for your backend services?" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Questions_Id",
                table: "Questions",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Questions");
        }
    }
}
