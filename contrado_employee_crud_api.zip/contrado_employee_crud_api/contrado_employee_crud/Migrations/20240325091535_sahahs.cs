﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace contrado_employee_crud.Migrations
{
    /// <inheritdoc />
    public partial class sahahs : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsEmailSend",
                table: "Employees",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "Result",
                table: "Employees",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsEmailSend",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "Result",
                table: "Employees");
        }
    }
}
