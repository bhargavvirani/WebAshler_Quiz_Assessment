﻿using System.Net;
using System.Net.Mail;

namespace contrado_employee_crud.Util
{
    public static class EmailUtility
    {
        
        public static async Task SendMail(string msg, string subject, string toAddress)
        {
            var configuration = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

            string senderEmail = configuration["EmailConfig:SenderEmail"]?.ToString();
            string senderPassword = configuration["EmailConfig:SenderPassword"]?.ToString();

            string receiverEmail = toAddress;

            SmtpClient smtpClient = new SmtpClient("smtp.example.com")
            {
                Port = 587,
                Credentials = new NetworkCredential(senderEmail, senderPassword),
                EnableSsl = true,
            };

            MailMessage mailMessage = new MailMessage
            {
                From = new MailAddress(senderEmail),
                Subject = subject,
                Body = msg,
                IsBodyHtml = false,
            };
            mailMessage.To.Add(receiverEmail);

            try
            {
                await smtpClient.SendMailAsync(mailMessage);
                Console.WriteLine("Email sent successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to send email: {ex.Message}");
            }
            finally
            {
                mailMessage.Dispose();
                smtpClient.Dispose();
            }
        }
    }
}
